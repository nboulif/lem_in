import lem_global as lg


