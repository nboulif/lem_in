import lem_global as lg

from vpython import vector

